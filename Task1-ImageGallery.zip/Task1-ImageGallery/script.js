const imagesData = [
    { src: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&q=80&w=800', category: 'nature' },
    { src: 'https://images.unsplash.com/photo-1542204165-65bf26472b9b?auto=format&fit=crop&q=80&w=800', category: 'nature' },
    { src: 'https://images.unsplash.com/photo-1449844908441-8829872d2607?auto=format&fit=crop&q=80&w=800', category: 'architecture' },
    { src: 'https://images.unsplash.com/photo-1518002171953-a080ee817e1f?auto=format&fit=crop&q=80&w=800', category: 'architecture' },
    { src: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=800', category: 'portrait' },
    { src: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=800', category: 'portrait' },
    { src: 'https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?auto=format&fit=crop&q=80&w=800', category: 'nature' },
    { src: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&q=80&w=800', category: 'nature' },
    { src: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?auto=format&fit=crop&q=80&w=800', category: 'architecture' },
    { src: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=800', category: 'portrait' },
    { src: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800', category: 'portrait' },
    { src: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800', category: 'architecture' }
];

document.addEventListener('DOMContentLoaded', () => {
    const galleryContainer = document.getElementById('gallery');
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxClose = document.getElementById('lightbox-close');
    const lightboxPrev = document.getElementById('lightbox-prev');
    const lightboxNext = document.getElementById('lightbox-next');
    
    let currentImageIndex = 0;
    let filteredImages = [...imagesData];

    // 1. Render Gallery
    function renderGallery(images) {
        galleryContainer.innerHTML = '';
        images.forEach((imgData, index) => {
            const item = document.createElement('div');
            item.className = `gallery-item`;
            
            // Adding a simple SVG plus icon for the hover effect
            item.innerHTML = `
                <img src="${imgData.src}" alt="Gallery Image" loading="lazy">
                <div class="icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                </div>
            `;
            
            item.addEventListener('click', () => openLightbox(index, images));
            galleryContainer.appendChild(item);
        });
    }

    renderGallery(imagesData);

    // 2. Filtering Logic
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const filterValue = btn.dataset.filter;
            
            if (filterValue === 'all') {
                filteredImages = [...imagesData];
            } else {
                filteredImages = imagesData.filter(img => img.category === filterValue);
            }
            
            renderGallery(filteredImages);
        });
    });

    // 3. Lightbox Logic
    function openLightbox(index, currentFilteredSet) {
        currentImageIndex = index;
        updateLightboxContent(currentFilteredSet[currentImageIndex]);
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden'; 
    }

    function closeLightbox() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }

    function updateLightboxContent(imgData) {
        // Remove high-resolution query params for preview, add for lightbox if needed
        // For simplicity, using the same image source but scaled
        lightboxImg.src = imgData.src.replace('&w=800', '&w=1600'); 
    }

    function showNext() {
        currentImageIndex = (currentImageIndex + 1) % filteredImages.length;
        updateLightboxContent(filteredImages[currentImageIndex]);
    }

    function showPrev() {
        currentImageIndex = (currentImageIndex - 1 + filteredImages.length) % filteredImages.length;
        updateLightboxContent(filteredImages[currentImageIndex]);
    }

    // Lightbox Event Listeners
    lightboxClose.addEventListener('click', closeLightbox);
    
    lightboxNext.addEventListener('click', (e) => {
        e.stopPropagation();
        showNext();
    });
    
    lightboxPrev.addEventListener('click', (e) => {
        e.stopPropagation();
        showPrev();
    });

    // Close lightbox on background click
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox || e.target === document.querySelector('.lightbox-content')) {
            closeLightbox();
        }
    });

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!lightbox.classList.contains('active')) return;
        
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowRight') showNext();
        if (e.key === 'ArrowLeft') showPrev();
    });
});
