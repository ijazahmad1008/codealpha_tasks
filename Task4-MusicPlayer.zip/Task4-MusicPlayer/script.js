const songs = [
    {
        "artist": "SoundHelix",
        "title": "Cyberpunk City Drive (Full)",
        "cover": "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&q=80&w=800",
        "src": "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
    },
    {
        "artist": "SoundHelix",
        "title": "Neon Nights (Full)",
        "cover": "https://images.unsplash.com/photo-1557672172-298e090bd0f1?auto=format&fit=crop&q=80&w=800",
        "src": "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
    },
    {
        "artist": "SoundHelix",
        "title": "Starlight Echoes (Full)",
        "cover": "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=800",
        "src": "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
    },
    {
        "artist": "SoundHelix",
        "title": "Digital Horizon (Full)",
        "cover": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
        "src": "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"
    },
    {
        "artist":  "Arijit Singh",
        "title":  "Tum Hi Ho",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/bb/23/ee/bb23eeed-0c35-4f1d-2b11-485622777ae4/8902894353007_cover.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/38/de/b9/38deb942-d44a-f2bb-205c-ddf05be84693/mzaf_9747647124859107103.plus.aac.p.m4a"
    },
    {
        "artist":  "Arijit Singh",
        "title":  "Channa Mereya",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/bc/6e/4d/bc6e4d0c-adec-b431-7b60-16f5689f9664/886446201597.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/d5/f9/98/d5f998a7-0090-ee2d-03f8-557ad6c5bf65/mzaf_14251357991592637728.plus.aac.p.m4a"
    },
    {
        "artist":  "Yo Yo Honey Singh",
        "title":  "Blue Eyes",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music71/v4/81/0b/a4/810ba47e-952c-8818-ad3c-9899b4928cd4/8902894354943_cover.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview125/v4/1a/44/fb/1a44fbe0-5172-ddad-8e53-5510ad7dcff9/mzaf_11119624523547880630.plus.aac.p.m4a"
    },
    {
        "artist":  "Yo Yo Honey Singh",
        "title":  "Desi Kalakaar",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/b3/b5/d9/b3b5d986-7f6d-a860-b8aa-769e1eef1a92/8902894356299_cover.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview125/v4/41/ca/70/41ca70be-2f8b-a239-4b5a-38b0432384c2/mzaf_15409144540645881266.plus.aac.p.m4a"
    },
    {
        "artist":  "Talha Anjum",
        "title":  "Gumaan",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/d4/f3/69/d4f36986-1fe2-0b4c-a2cf-54192ded03ae/artwork.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview116/v4/2d/c5/5a/2dc55a6c-4604-b5c6-d619-d8ef2be6d633/mzaf_9158600008276320472.plus.aac.p.m4a"
    },
    {
        "artist":  "Talha Anjum",
        "title":  "Afsanay",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music211/v4/8b/05/74/8b057495-90b4-f039-0bfe-c0a839e940f1/5059713011204_cover.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/7f/ae/54/7fae542f-e72a-5311-b3cd-0545b1f8f51b/mzaf_3803327232855867334.plus.aac.p.m4a"
    },
    {
        "artist":  "Nusrat Fateh Ali Khan",
        "title":  "Mere Rashke Qamar",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music114/v4/0e/2d/45/0e2d45b2-c989-e76f-0510-06800917f1c8/8903431648372_cover.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview125/v4/f6/f6/5c/f6f65c14-f87e-f5a7-bb1f-ed85a8d88a52/mzaf_17371629668800570088.plus.aac.p.m4a"
    },
    {
        "artist":  "Nusrat Fateh Ali Khan",
        "title":  "Yeh Jo Halka Halka Saroor",
        "cover":  "https://is1-ssl.mzstatic.com/image/thumb/Music221/v4/d0/ca/66/d0ca6662-2b9d-3b07-494c-44756232918a/24UM1IM20242.rgb.jpg/600x600bb.jpg",
        "src":  "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/be/03/8f/be038f09-7799-9c06-a388-75237941b915/mzaf_8588201380822914861.plus.aac.p.m4a"
    }
];

const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const repeatBtn = document.getElementById('repeat');
const shuffleBtn = document.getElementById('shuffle');
const title = document.getElementById('title');
const artist = document.getElementById('artist');
const cover = document.getElementById('cover');
const progress = document.getElementById('progress');
const currentTimeEl = document.getElementById('current-time');
const durationEl = document.getElementById('duration');
const volumeSlider = document.getElementById('volume');
const muteIcon = document.getElementById('mute-icon');
const musicPlayer = document.querySelector('.music-player');
const bgOverlay = document.querySelector('.background-overlay');
const playlistEl = document.getElementById('playlist');
const searchInput = document.getElementById('search-input');
const likeBtn = document.getElementById('like-btn');
const speedBtn = document.getElementById('speed-btn');
const downloadBtn = document.getElementById('download-btn');
const themeBtn = document.getElementById('theme-btn');
const sleepBtn = document.getElementById('sleep-btn');
const sleepText = document.getElementById('sleep-text');

let songIndex = 0;
let isPlaying = false;
let isRepeat = false;
let isShuffle = false;
let playbackSpeeds = [1, 1.5, 2];
let currentSpeedIdx = 0;
let likedSongs = new Set();
let sleepTimerModes = [0, 15, 30, 60]; // 0 means off
let currentSleepIdx = 0;
let sleepTimeout = null;

// Initialize
function loadSong(song) {
    title.innerText = song.title;
    artist.innerText = song.artist;
    audio.src = song.src;
    cover.src = song.cover;
    bgOverlay.style.backgroundImage = `url('${song.cover}')`;
    
    // Update Download Link
    downloadBtn.href = song.src;
    
    // Update Like Button state
    if (likedSongs.has(song.title)) {
        likeBtn.style.color = '#ef4444'; // Red
    } else {
        likeBtn.style.color = 'var(--text-secondary)'; // Gray
    }
    
    updatePlaylistActiveState();
}

// Play & Pause
function playSong() {
    isPlaying = true;
    musicPlayer.classList.add('playing');
    playBtn.innerHTML = '<i class="fas fa-pause"></i>';
    audio.play();
}

function pauseSong() {
    isPlaying = false;
    musicPlayer.classList.remove('playing');
    playBtn.innerHTML = '<i class="fas fa-play"></i>';
    audio.pause();
}

playBtn.addEventListener('click', () => {
    if (isPlaying) {
        pauseSong();
    } else {
        playSong();
    }
});

// Next & Prev
function prevSong() {
    if (isShuffle) {
        songIndex = Math.floor(Math.random() * songs.length);
    } else {
        songIndex--;
        if (songIndex < 0) {
            songIndex = songs.length - 1;
        }
    }
    loadSong(songs[songIndex]);
    if(isPlaying) playSong();
}

function nextSong() {
    if (isShuffle) {
        let newIndex = Math.floor(Math.random() * songs.length);
        while (newIndex === songIndex && songs.length > 1) {
            newIndex = Math.floor(Math.random() * songs.length);
        }
        songIndex = newIndex;
    } else {
        songIndex++;
        if (songIndex > songs.length - 1) {
            songIndex = 0;
        }
    }
    loadSong(songs[songIndex]);
    if(isPlaying) playSong();
}

prevBtn.addEventListener('click', prevSong);
nextBtn.addEventListener('click', nextSong);

// Repeat and Shuffle Logic
repeatBtn.addEventListener('click', () => {
    isRepeat = !isRepeat;
    repeatBtn.classList.toggle('active', isRepeat);
});

shuffleBtn.addEventListener('click', () => {
    isShuffle = !isShuffle;
    shuffleBtn.classList.toggle('active', isShuffle);
});

// Autoplay next song bonus feature (handles repeat logic)
audio.addEventListener('ended', () => {
    if (isRepeat) {
        audio.currentTime = 0;
        playSong();
    } else {
        nextSong();
    }
});

// Like Button Logic
likeBtn.addEventListener('click', () => {
    const currentTitle = songs[songIndex].title;
    if (likedSongs.has(currentTitle)) {
        likedSongs.delete(currentTitle);
        likeBtn.style.color = 'var(--text-secondary)';
    } else {
        likedSongs.add(currentTitle);
        likeBtn.style.color = '#ef4444'; // Red
        // Little pop animation
        likeBtn.style.transform = 'scale(1.3)';
        setTimeout(() => likeBtn.style.transform = 'scale(1)', 200);
    }
});

// Playback Speed Logic
speedBtn.addEventListener('click', () => {
    currentSpeedIdx = (currentSpeedIdx + 1) % playbackSpeeds.length;
    const speed = playbackSpeeds[currentSpeedIdx];
    audio.playbackRate = speed;
    speedBtn.innerText = speed + 'x';
});

// Sleep Timer Logic
sleepBtn.addEventListener('click', () => {
    currentSleepIdx = (currentSleepIdx + 1) % sleepTimerModes.length;
    let minutes = sleepTimerModes[currentSleepIdx];
    
    if (sleepTimeout) clearTimeout(sleepTimeout);
    
    if (minutes === 0) {
        sleepText.innerText = '';
        sleepBtn.classList.remove('active');
    } else {
        sleepText.innerText = minutes + 'm';
        sleepBtn.classList.add('active');
        sleepTimeout = setTimeout(() => {
            pauseSong();
            // Reset
            currentSleepIdx = 0;
            sleepText.innerText = '';
            sleepBtn.classList.remove('active');
        }, minutes * 60 * 1000);
    }
});

// Theme Toggle Logic
themeBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    if(document.body.classList.contains('light-mode')) {
        themeBtn.classList.remove('fa-sun');
        themeBtn.classList.add('fa-moon');
    } else {
        themeBtn.classList.remove('fa-moon');
        themeBtn.classList.add('fa-sun');
    }
});

// Keyboard Shortcuts
document.addEventListener('keydown', (e) => {
    // Ignore if typing in search input
    if (e.target.tagName === 'INPUT') return;
    
    if (e.code === 'Space') {
        e.preventDefault();
        if (isPlaying) pauseSong(); else playSong();
    } else if (e.code === 'ArrowRight') {
        nextSong();
    } else if (e.code === 'ArrowLeft') {
        prevSong();
    } else if (e.code === 'ArrowUp') {
        e.preventDefault();
        if (audio.volume <= 0.9) {
            audio.volume += 0.1;
            volumeSlider.value = audio.volume;
            updateVolumeIcon();
        }
    } else if (e.code === 'ArrowDown') {
        e.preventDefault();
        if (audio.volume >= 0.1) {
            audio.volume -= 0.1;
            volumeSlider.value = audio.volume;
            updateVolumeIcon();
        }
    }
});

// Progress Bar Updates
function updateProgress(e) {
    const { duration, currentTime } = e.srcElement;
    
    // Update progress bar value
    if (duration) {
        const progressPercent = (currentTime / duration) * 100;
        progress.value = progressPercent;
        
        // Calculate display time
        let currentMins = Math.floor(currentTime / 60);
        let currentSecs = Math.floor(currentTime % 60);
        if (currentSecs < 10) currentSecs = `0${currentSecs}`;
        currentTimeEl.innerText = `${currentMins}:${currentSecs}`;
    }
}

function setProgress(e) {
    const width = this.clientWidth;
    const clickX = e.offsetX;
    const duration = audio.duration;
    if(duration) {
        audio.currentTime = (clickX / width) * duration;
    }
}

audio.addEventListener('timeupdate', updateProgress);
progress.addEventListener('click', setProgress);

// Load duration metadata
audio.addEventListener('loadedmetadata', () => {
    const duration = audio.duration;
    let durationMins = Math.floor(duration / 60);
    let durationSecs = Math.floor(duration % 60);
    if (durationSecs < 10) durationSecs = `0${durationSecs}`;
    durationEl.innerText = `${durationMins}:${durationSecs}`;
});

// Volume Control
volumeSlider.addEventListener('input', (e) => {
    audio.volume = e.target.value;
    updateVolumeIcon();
});

function updateVolumeIcon() {
    if (audio.volume === 0) {
        muteIcon.className = 'fas fa-volume-mute';
    } else if (audio.volume < 0.5) {
        muteIcon.className = 'fas fa-volume-down';
    } else {
        muteIcon.className = 'fas fa-volume-up';
    }
}

muteIcon.addEventListener('click', () => {
    if (audio.volume > 0) {
        audio.dataset.savedVolume = audio.volume;
        audio.volume = 0;
        volumeSlider.value = 0;
    } else {
        const savedVol = audio.dataset.savedVolume || 1;
        audio.volume = savedVol;
        volumeSlider.value = savedVol;
    }
    updateVolumeIcon();
});

// Playlist Generation
function generatePlaylist() {
    playlistEl.innerHTML = '';
    songs.forEach((song, index) => {
        const li = document.createElement('li');
        li.dataset.index = index;
        li.innerHTML = `
            <img src="${song.cover}" class="list-thumb" alt="${song.title}">
            <div class="list-info">
                <h4 class="song-title-text">${song.title}</h4>
                <p class="song-artist-text">${song.artist}</p>
            </div>
            <i class="fas fa-chart-bar list-playing-icon"></i>
        `;
        
        li.addEventListener('click', () => {
            songIndex = index;
            loadSong(songs[songIndex]);
            playSong();
        });
        
        playlistEl.appendChild(li);
    });
}

function updatePlaylistActiveState() {
    const items = playlistEl.querySelectorAll('li');
    items.forEach((item) => {
        if (parseInt(item.dataset.index) === songIndex) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
}

// Search Functionality
searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    const items = playlistEl.querySelectorAll('li');
    
    items.forEach((item) => {
        const titleText = item.querySelector('.song-title-text').innerText.toLowerCase();
        const artistText = item.querySelector('.song-artist-text').innerText.toLowerCase();
        
        if (titleText.includes(query) || artistText.includes(query)) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
});

// Initial Load
generatePlaylist();
loadSong(songs[songIndex]);
